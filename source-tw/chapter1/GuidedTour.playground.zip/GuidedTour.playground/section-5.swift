var myVariable = 42
myVariable = 50
let myConstant = 42
