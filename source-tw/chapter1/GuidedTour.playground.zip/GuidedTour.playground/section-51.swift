var shape = Shape()
shape.numberOfSides = 7
var shapeDescription = shape.simpleDescription()
